SVG available upon request.
