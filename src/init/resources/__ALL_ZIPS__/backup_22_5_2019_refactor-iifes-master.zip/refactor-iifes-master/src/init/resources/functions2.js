console.log('Heyyy');

(function mpampis() { /* IIFE unnamed in simplest form */ })();