class Statement {

    constructor(stmtASTNode){

    }

    isFunctionDeclaration(){
        return false;
    }


}