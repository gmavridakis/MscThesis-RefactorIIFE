var bitmapFontDataFixture = "info face=\"Arial\" size=18 bold=0 italic=0 charset=\"\" unicode=0 stretchH=100 smooth=1 aa=1 padding=0,0,0,0 spacing=0,0\n" +
"common lineHeight=22 base=19 scaleW=256 scaleH=256 pages=1 packed=0\n" +
"page id=0 file=\"arialfancy.png\"\n" +
"chars count=95\n" +
"char id=32 x=24 y=20 width=0 height=0 xoffset=0 yoffset=17 xadvance=6 page=0 chnl=0\n" +
"char id=33 x=192 y=38 width=8 height=16 xoffset=2 yoffset=3 xadvance=6 page=0 chnl=0\n" +
"char id=34 x=242 y=46 width=8 height=8 xoffset=3 yoffset=2 xadvance=7 page=0 chnl=0\n" +
"char id=35 x=104 y=38 width=12 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=36 x=18 y=60 width=12 height=18 xoffset=1 yoffset=2 xadvance=11 page=0 chnl=0\n" +
"char id=37 x=230 y=2 width=16 height=16 xoffset=2 yoffset=3 xadvance=17 page=0 chnl=0\n" +
"char id=38 x=18 y=42 width=14 height=16 xoffset=2 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=39 x=48 y=124 width=6 height=8 xoffset=3 yoffset=2 xadvance=4 page=0 chnl=0\n" +
"char id=40 x=48 y=78 width=8 height=20 xoffset=2 yoffset=2 xadvance=6 page=0 chnl=0\n" +
"char id=41 x=48 y=56 width=8 height=20 xoffset=0 yoffset=2 xadvance=6 page=0 chnl=0\n" +
"char id=42 x=232 y=46 width=8 height=8 xoffset=3 yoffset=3 xadvance=8 page=0 chnl=0\n" +
"char id=43 x=226 y=24 width=12 height=12 xoffset=2 yoffset=4 xadvance=11 page=0 chnl=0\n" +
"char id=44 x=48 y=114 width=6 height=8 xoffset=1 yoffset=13 xadvance=6 page=0 chnl=0\n" +
"char id=45 x=212 y=50 width=8 height=4 xoffset=1 yoffset=11 xadvance=6 page=0 chnl=0\n" +
"char id=46 x=48 y=134 width=6 height=4 xoffset=2 yoffset=15 xadvance=6 page=0 chnl=0\n" +
"char id=47 x=90 y=38 width=12 height=16 xoffset=0 yoffset=3 xadvance=6 page=0 chnl=0\n" +
"char id=48 x=76 y=38 width=12 height=16 xoffset=2 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=49 x=182 y=38 width=8 height=16 xoffset=3 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=50 x=62 y=38 width=12 height=16 xoffset=2 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=51 x=48 y=38 width=12 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=52 x=34 y=236 width=12 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=53 x=34 y=218 width=12 height=16 xoffset=2 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=54 x=34 y=200 width=12 height=16 xoffset=2 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=55 x=34 y=182 width=12 height=16 xoffset=3 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=56 x=34 y=164 width=12 height=16 xoffset=2 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=57 x=34 y=146 width=12 height=16 xoffset=2 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=58 x=48 y=100 width=6 height=12 xoffset=2 yoffset=7 xadvance=6 page=0 chnl=0\n" +
"char id=59 x=202 y=38 width=8 height=14 xoffset=1 yoffset=7 xadvance=6 page=0 chnl=0\n" +
"char id=60 x=212 y=24 width=12 height=12 xoffset=2 yoffset=5 xadvance=11 page=0 chnl=0\n" +
"char id=61 x=18 y=244 width=12 height=8 xoffset=2 yoffset=7 xadvance=11 page=0 chnl=0\n" +
"char id=62 x=198 y=24 width=12 height=12 xoffset=2 yoffset=5 xadvance=11 page=0 chnl=0\n" +
"char id=63 x=130 y=38 width=10 height=16 xoffset=3 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=64 x=2 y=2 width=20 height=20 xoffset=1 yoffset=2 xadvance=19 page=0 chnl=0\n" +
"char id=65 x=18 y=24 width=14 height=16 xoffset=0 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=66 x=2 y=222 width=14 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=67 x=2 y=204 width=14 height=16 xoffset=2 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=68 x=212 y=2 width=16 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=69 x=2 y=186 width=14 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=70 x=2 y=168 width=14 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=71 x=194 y=2 width=16 height=16 xoffset=2 yoffset=3 xadvance=15 page=0 chnl=0\n" +
"char id=72 x=176 y=2 width=16 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=73 x=172 y=38 width=8 height=16 xoffset=2 yoffset=3 xadvance=6 page=0 chnl=0\n" +
"char id=74 x=34 y=128 width=12 height=16 xoffset=1 yoffset=3 xadvance=9 page=0 chnl=0\n" +
"char id=75 x=158 y=2 width=16 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=76 x=34 y=110 width=12 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=77 x=84 y=2 width=18 height=16 xoffset=1 yoffset=3 xadvance=15 page=0 chnl=0\n" +
"char id=78 x=140 y=2 width=16 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=79 x=122 y=2 width=16 height=16 xoffset=2 yoffset=3 xadvance=15 page=0 chnl=0\n" +
"char id=80 x=2 y=150 width=14 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=81 x=66 y=2 width=16 height=18 xoffset=2 yoffset=2 xadvance=15 page=0 chnl=0\n" +
"char id=82 x=104 y=2 width=16 height=16 xoffset=1 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=83 x=2 y=132 width=14 height=16 xoffset=2 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=84 x=2 y=114 width=14 height=16 xoffset=3 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=85 x=2 y=96 width=14 height=16 xoffset=2 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=86 x=2 y=78 width=14 height=16 xoffset=3 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=87 x=24 y=2 width=20 height=16 xoffset=3 yoffset=3 xadvance=17 page=0 chnl=0\n" +
"char id=88 x=46 y=2 width=18 height=16 xoffset=0 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=89 x=2 y=60 width=14 height=16 xoffset=3 yoffset=3 xadvance=13 page=0 chnl=0\n" +
"char id=90 x=2 y=42 width=14 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=91 x=18 y=168 width=10 height=20 xoffset=1 yoffset=2 xadvance=6 page=0 chnl=0\n" +
"char id=92 x=224 y=38 width=6 height=16 xoffset=2 yoffset=3 xadvance=6 page=0 chnl=0\n" +
"char id=93 x=18 y=146 width=10 height=20 xoffset=-1 yoffset=2 xadvance=6 page=0 chnl=0\n" +
"char id=94 x=212 y=38 width=10 height=10 xoffset=2 yoffset=2 xadvance=9 page=0 chnl=0\n" +
"char id=95 x=58 y=56 width=14 height=4 xoffset=-1 yoffset=18 xadvance=11 page=0 chnl=0\n" +
"char id=96 x=246 y=38 width=6 height=6 xoffset=3 yoffset=2 xadvance=6 page=0 chnl=0\n" +
"char id=97 x=184 y=24 width=12 height=12 xoffset=1 yoffset=7 xadvance=11 page=0 chnl=0\n" +
"char id=98 x=34 y=92 width=12 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=99 x=170 y=24 width=12 height=12 xoffset=2 yoffset=7 xadvance=9 page=0 chnl=0\n" +
"char id=100 x=34 y=74 width=12 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=101 x=156 y=24 width=12 height=12 xoffset=1 yoffset=7 xadvance=11 page=0 chnl=0\n" +
"char id=102 x=118 y=38 width=10 height=16 xoffset=1 yoffset=3 xadvance=6 page=0 chnl=0\n" +
"char id=103 x=34 y=56 width=12 height=16 xoffset=1 yoffset=6 xadvance=11 page=0 chnl=0\n" +
"char id=104 x=34 y=38 width=12 height=16 xoffset=1 yoffset=3 xadvance=11 page=0 chnl=0\n" +
"char id=105 x=162 y=38 width=8 height=16 xoffset=1 yoffset=3 xadvance=4 page=0 chnl=0\n" +
"char id=106 x=18 y=124 width=10 height=20 xoffset=-2 yoffset=2 xadvance=4 page=0 chnl=0\n" +
"char id=107 x=18 y=226 width=12 height=16 xoffset=1 yoffset=3 xadvance=9 page=0 chnl=0\n" +
"char id=108 x=152 y=38 width=8 height=16 xoffset=1 yoffset=3 xadvance=4 page=0 chnl=0\n" +
"char id=109 x=34 y=24 width=18 height=12 xoffset=1 yoffset=7 xadvance=15 page=0 chnl=0\n" +
"char id=110 x=142 y=24 width=12 height=12 xoffset=1 yoffset=7 xadvance=11 page=0 chnl=0\n" +
"char id=111 x=128 y=24 width=12 height=12 xoffset=1 yoffset=7 xadvance=11 page=0 chnl=0\n" +
"char id=112 x=18 y=208 width=12 height=16 xoffset=0 yoffset=6 xadvance=11 page=0 chnl=0\n" +
"char id=113 x=18 y=190 width=12 height=16 xoffset=1 yoffset=6 xadvance=11 page=0 chnl=0\n" +
"char id=114 x=240 y=24 width=10 height=12 xoffset=1 yoffset=7 xadvance=6 page=0 chnl=0\n" +
"char id=115 x=114 y=24 width=12 height=12 xoffset=1 yoffset=7 xadvance=9 page=0 chnl=0\n" +
"char id=116 x=142 y=38 width=8 height=16 xoffset=2 yoffset=3 xadvance=6 page=0 chnl=0\n" +
"char id=117 x=100 y=24 width=12 height=12 xoffset=2 yoffset=7 xadvance=11 page=0 chnl=0\n" +
"char id=118 x=86 y=24 width=12 height=12 xoffset=2 yoffset=7 xadvance=9 page=0 chnl=0\n" +
"char id=119 x=54 y=24 width=16 height=12 xoffset=2 yoffset=7 xadvance=13 page=0 chnl=0\n" +
"char id=120 x=72 y=24 width=12 height=12 xoffset=0 yoffset=7 xadvance=9 page=0 chnl=0\n" +
"char id=121 x=2 y=24 width=14 height=16 xoffset=0 yoffset=6 xadvance=9 page=0 chnl=0\n" +
"char id=122 x=2 y=240 width=12 height=12 xoffset=1 yoffset=7 xadvance=9 page=0 chnl=0\n" +
"char id=123 x=18 y=102 width=10 height=20 xoffset=1 yoffset=2 xadvance=7 page=0 chnl=0\n" +
"char id=124 x=248 y=2 width=4 height=20 xoffset=2 yoffset=2 xadvance=5 page=0 chnl=0\n" +
"char id=125 x=18 y=80 width=10 height=20 xoffset=-1 yoffset=2 xadvance=7 page=0 chnl=0\n" +
"char id=126 x=232 y=38 width=12 height=6 xoffset=2 yoffset=8 xadvance=11 page=0 chnl=0\n" +
"kernings count=38\n" +
"kerning first=84 second=97 amount=-1\n" +
"kerning first=84 second=99 amount=-1\n" +
"kerning first=80 second=65 amount=-1\n" +
"kerning first=89 second=111 amount=-1\n" +
"kerning first=84 second=111 amount=-1\n" +
"kerning first=89 second=112 amount=-1\n" +
"kerning first=84 second=65 amount=-1\n" +
"kerning first=80 second=44 amount=-2\n" +
"kerning first=89 second=113 amount=-1\n" +
"kerning first=76 second=84 amount=-1\n" +
"kerning first=80 second=46 amount=-2\n" +
"kerning first=76 second=86 amount=-1\n" +
"kerning first=76 second=87 amount=-1\n" +
"kerning first=84 second=58 amount=-1\n" +
"kerning first=84 second=44 amount=-1\n" +
"kerning first=84 second=115 amount=-1\n" +
"kerning first=76 second=89 amount=-1\n" +
"kerning first=84 second=46 amount=-1\n" +
"kerning first=89 second=97 amount=-1\n" +
"kerning first=89 second=101 amount=-1\n" +
"kerning first=49 second=49 amount=-1\n" +
"kerning first=84 second=101 amount=-1\n" +
"kerning first=86 second=97 amount=-1\n" +
"kerning first=89 second=65 amount=-1\n" +
"kerning first=118 second=44 amount=-1\n" +
"kerning first=65 second=84 amount=-1\n" +
"kerning first=65 second=86 amount=-1\n" +
"kerning first=118 second=46 amount=-1\n" +
"kerning first=65 second=89 amount=-1\n" +
"kerning first=89 second=44 amount=-2\n" +
"kerning first=86 second=65 amount=-1\n" +
"kerning first=89 second=46 amount=-2\n" +
"kerning first=121 second=44 amount=-1\n" +
"kerning first=70 second=44 amount=-1\n" +
"kerning first=86 second=44 amount=-1\n" +
"kerning first=70 second=46 amount=-1\n" +
"kerning first=121 second=46 amount=-1\n" +
"kerning first=86 second=46 amount=-1";

describe("me.BitmapFontData", function () {
    describe("parse", function () {
        var bitmapFontData = null;
        beforeEach(function () {
            bitmapFontData = new me.BitmapFontData(bitmapFontDataFixture);
        });

        it("should have 95 glyphs", function () {
            expect(Object.keys(bitmapFontData.glyphs).length).toEqual(95);
        });

        it("glyph by character 33 should have set data", function () {
            var glyph = bitmapFontData.glyphs[33];
            expect(glyph.x).toEqual(192);
            expect(glyph.y).toEqual(38);
            expect(glyph.width).toEqual(8);
            expect(glyph.height).toEqual(16);
            expect(glyph.xoffset).toEqual(2);
            expect(glyph.yoffset).toEqual(3);
            expect(glyph.xadvance).toEqual(6);
        });

        it("glyph by character 70 should have kerning data", function () {
            var glyph = bitmapFontData.glyphs[70];
            expect(glyph.getKerning(44)).toEqual(-1);
        });
    });
});
