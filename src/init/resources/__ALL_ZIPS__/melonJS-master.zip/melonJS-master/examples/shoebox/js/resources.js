game.resources = [
    { name : "texture", type : "json", src : "data/img/shoebox.json" },
    { name : "texture", type : "image", src : "data/img/shoebox.png" }
];
