game.resources = [
    { name : "basicImage", src : "data/img/basicImage.png", type : "image" }
];
