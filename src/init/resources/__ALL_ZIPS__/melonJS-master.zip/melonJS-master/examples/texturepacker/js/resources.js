game.resources = [
    { name : "cityscene", type : "json", src : "data/img/cityscene.json" },
    { name : "cityscene", type : "image", src : "data/img/cityscene.png" }
];
