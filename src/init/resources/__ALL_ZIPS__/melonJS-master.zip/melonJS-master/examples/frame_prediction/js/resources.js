game.resources = [

    { name: "ball", type: "image", src: "data/img/ball.png" },
    { name: "tiles", type: "image", src: "data/img/tiles.png" },
    { name: "room", type: "tmx", src: "data/map/room.tmx" },
    { name: "tiles", type: "tsx", src: "data/map/tiles.tsx" }

];
