
import "jay-extend";

/**
 * The base class from which all melonJS objects inherit.
 * See: {@link https://github.com/parasyte/jay-extend}
 * @class
 * @memberOf me
 */
me.Object = window.Jay;
